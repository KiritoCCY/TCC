<!DOCTYPE html>
<html>
<head>
    <title>Email Management System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2 class="text-center">Welcome to Email Management System</h2>
    <div class="row">
        <div class="col-md-12 text-center">
            <a href="add.php" class="btn btn-primary">Add New Record</a>
            <a href="view.php" class="btn btn-success">View Records</a>
        </div>
    </div>
</div>
</body>
</html>
