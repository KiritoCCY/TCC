<?php
// add.php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    
    $sql = "INSERT INTO contacts (name, phone, email, address) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $phone, $email, $address);
    
    if ($stmt->execute()) {
        header("Location: view.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Contact --- TeleSys</title>
    
</head>
<body>
    <nav class="navbar">
        <a href="index.php">Homepage</a>
        <a href="view.php">View Contact</a>
        <a href="add.php">Add Contact</a>
    </nav>
    <div class="container">
        <div class="card">
            <h2>Add New Contact</h2>
            <form method="POST" action="add.php">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone no.</label>
                    <input type="tel" id="phone" name="phone">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" id="address" name="address">
                </div>
                <button type="submit" class="btn">Add Contact</button>
            </form>
        </div>
    </div>
</body>
</html>