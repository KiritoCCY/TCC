<?php
// index.php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TeleSys</title>

</head>
<body>
    <nav class="navbar">
        <a href="index.php">Homepage</a>
        <a href="view.php">View Contact</a>
        <a href="add.php">Add Contact</a>
    </nav>
    <div class="container">
        <div class="card">
            <h1>Welcome!</h1>
            <p>What you want to do? </p>
            <div>
                <a href="view.php" class="btn">View Contact</a>
                <a href="add.php" class="btn">Add Contact</a>
            </div>
        </div>
    </div>
</body>
</html>