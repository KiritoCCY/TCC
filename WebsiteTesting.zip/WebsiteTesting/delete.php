<?php
// delete.php
require_once 'config.php';

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    
    // First check if contact exists
    $check_sql = "SELECT id FROM contacts WHERE id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows === 0) {
        die('Contact not found');
    }
    
    // Perform delete operation
    $delete_sql = "DELETE FROM contacts WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("i", $id);
    
    if ($delete_stmt->execute()) {
        header("Location: view.php");
        exit();
    } else {
        die('Delete failed, please try again');
    }
} else {
    die('Invalid request');
}
?>