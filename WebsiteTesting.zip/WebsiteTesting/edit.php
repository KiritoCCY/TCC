<?php
// edit.php
require_once 'config.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$error_message = '';
$success_message = '';

// Get contact information
function get_contact($conn, $id) {
    $sql = "SELECT * FROM contacts WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = (int)$_POST['id'];
    $name = sanitize_input($_POST['name']);
    $phone = sanitize_input($_POST['phone']);
    $email = sanitize_input($_POST['email']);
    $address = sanitize_input($_POST['address']);
    
    if (empty($name)) {
        $error_message = 'Name cannot be empty';
    } else {
        $sql = "UPDATE contacts SET name=?, phone=?, email=?, address=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $name, $phone, $email, $address, $id);
        
        if ($stmt->execute()) {
            $success_message = 'Contact updated successfully!';
            header("Location: view.php");
            exit();
        } else {
            $error_message = 'Update failed, please try again';
        }
    }
}

$contact = get_contact($conn, $id);
if (!$contact) {
    die('Contact not found');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Contact - Contact Book System</title>
</head>
<body>
    <nav class="navbar">
        <a href="index.php">Home</a>
        <a href="view.php">View Contacts</a>
        <a href="add.php">Add Contact</a>
    </nav>
    
    <div class="container">
        <div class="card">
            <h2>Edit Contact</h2>
            
            <?php if ($error_message): ?>
                <div class="alert alert-error"><?php echo $error_message; ?></div>
            <?php endif; ?>
            
            <?php if ($success_message): ?>
                <div class="alert alert-success"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="edit.php">
                <input type="hidden" name="id" value="<?php echo $contact['id']; ?>">
                
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" 
                           value="<?php echo htmlspecialchars($contact['name']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" name="phone" 
                           value="<?php echo htmlspecialchars($contact['phone']); ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" 
                           value="<?php echo htmlspecialchars($contact['email']); ?>">
                </div>
                
                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" id="address" name="address" 
                           value="<?php echo htmlspecialchars($contact['address']); ?>">
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn">Save Changes</button>
                    <a href="view.php" class="btn">Back to List</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
