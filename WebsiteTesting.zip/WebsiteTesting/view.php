<?php
// view.php
require_once 'config.php';

$sql = "SELECT * FROM contacts ORDER BY name";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Contacts - Contact Book System</title>
</head>
<body>
    <nav class="navbar">
        <a href="index.php">Home</a>
        <a href="view.php">View Contacts</a>
        <a href="add.php">Add Contact</a>
    </nav>
    
    <div class="container">
        <div class="card">
            <h2>Contact List</h2>
            <?php if ($result && $result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['address']); ?></td>
                                <td>
                                    <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn">Edit</a>
                                    <a href="delete.php?id=<?php echo $row['id']; ?>" 
                                       class="btn" 
                                       onclick="return confirm('Are you sure you want to delete this contact?')">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No contacts found</p>
            <?php endif; ?>
            <div style="margin-top: 20px;">
                <a href="add.php" class="btn">Add New Contact</a>
            </div>
        </div>
    </div>
</body>
</html>
