<?php
    require_once 'config.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        
        $sql = "INSERT INTO data (firstname, email) VALUES ('$firstname', '$email')";
        
        if ($conn->query($sql) === TRUE) {
            echo "<div class='alert alert-success'>Record added successfully</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div>";
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add New Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2>Add New Record</h2>
    <form method="post">
        <div class="form-group">
            <label for="firstname">Name:</label>
            <input type="text" class="form-control" name="firstname" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" name="email" required>
        </div>
        <button type="submit" class="btn btn-success">Submit</button>
        <a href="index.php" class="btn btn-default">Back</a>
    </form>
</div>
</body>
</html>