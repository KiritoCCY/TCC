<?php
require_once 'config.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    if (isset($_GET['id'])) {
        $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
        if ($id === false || $id <= 0) {
            throw new Exception("Invalid ID");
        }

        $sql = "SELECT * FROM data WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception("Record not found");
        }
        
        $row = $result->fetch_assoc();
        $stmt->close();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = filter_var($_POST['id'], FILTER_VALIDATE_INT);
        if ($id === false || $id <= 0) {
            throw new Exception("Invalid ID in form submission");
        }

        if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }


        $update_sql = "UPDATE data SET firstname = ?, email = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ssi", $_POST['firstname'], $_POST['email'], $id);

        if ($update_stmt->execute()) {
            echo "<script>alert('Record updated successfully'); window.location.href = 'view.php';</script>";
            exit();
        } else {
            throw new Exception("Error updating record: " . $update_stmt->error);
        }
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>" . $e->getMessage() . "</div>";
    echo "<a href='view.php' class='btn btn-primary'>Back to List</a>";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2>Edit Record</h2>
    <?php if (isset($row)): ?>
        <form method="post" onsubmit="return confirm('Are you sure you want to update this record?');">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
            <div class="form-group">
                <label for="firstname">Name:</label>
                <input type="text" class="form-control" name="firstname" 
                       value="<?php echo htmlspecialchars($row['firstname']); ?>" 
                       required maxlength="30">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" name="email" 
                       value="<?php echo htmlspecialchars($row['email']); ?>" 
                       required maxlength="50">
            </div>
            <button type="submit" class="btn btn-success">Update</button>
            <a href="view.php" class="btn btn-default">Back</a>
        </form>
    <?php endif; ?>
</div>
</body>
</html>