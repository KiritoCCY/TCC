<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

try {

    if (!isset($_GET['id']) || empty($_GET['id'])) {
        throw new Exception("No ID provided");
    }
    
 
    $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
    if ($id === false || $id <= 0) {
        throw new Exception("Invalid ID format");
    }
    
   
    $check_sql = "SELECT id FROM data WHERE id = ?";
    $check_stmt = $conn->prepare($check_sql);
    if (!$check_stmt) {
        throw new Exception("Prepare check statement failed: " . $conn->error);
    }
    
    $check_stmt->bind_param("i", $id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception("Record with ID $id not found");
    }
    $check_stmt->close();
    

    $delete_sql = "DELETE FROM data WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    if (!$delete_stmt) {
        throw new Exception("Prepare delete statement failed: " . $conn->error);
    }
    
    $delete_stmt->bind_param("i", $id);
    
    if (!$delete_stmt->execute()) {
        throw new Exception("Delete failed: " . $delete_stmt->error);
    }
    
    $delete_stmt->close();
    $conn->close();
    

    header("Location: view.php");
    exit();
    
} catch (Exception $e) {

    echo "<div style='margin: 20px;'>";
    echo "<h3 style='color: red;'>Error: " . $e->getMessage() . "</h3>";
    echo "<a href='view.php' class='btn btn-primary'>Back</a>";
    echo "</div>";
}
?>
