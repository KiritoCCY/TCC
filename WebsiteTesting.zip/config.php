<!-- config.php - Database configuration -->
<?php
$servername = "intelli.coghw13fheqo.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "TCCproject.123";
$db = "TCCDB";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>